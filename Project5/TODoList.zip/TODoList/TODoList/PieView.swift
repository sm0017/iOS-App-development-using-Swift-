//
//  PieView.swift
//  TODoList App : COS 470: Final Project
//  Created by Smita Sukhadeve on 5/6/16.
//  Copyright © 2016 USM. All rights reserved.
//

import UIKit

// gets the data from the PieViewController to draw the PieView
// This is an attempt to draw the pie chart which could shows completed and uncompleted tasks
// Story borad showed warnings about agent crashing while rendering the custom view. I tried searching on the error but couldn't find the solution
//why it could not render custom Ui View. Hence I had to comment out the @IBDesignable,  @IBInspectable
// Used CoreGraphic and UIBazier path to draw the PieChart

protocol CircleViewDataSource: class {
    func completedtask(sender: PieView) -> Double
}

//@IBDesignable
class PieView: UIView {
    
    // @IBInspectable
    var lineWidth: CGFloat = 3 { didSet { setNeedsDisplay() } }
    // @IBInspectable
    var color: UIColor = UIColor.blueColor() { didSet { setNeedsDisplay() } }
    
    //  @IBInspectable
    var scale: CGFloat = 0.50 { didSet { setNeedsDisplay() } }
    
    // Get the center for drawing the circle
    private var circleCenter: CGPoint {
        return convertPoint(center, fromView: superview)
    }
    
    // declare datasourec for the PieView
    weak var dataSource: CircleViewDataSource?
    
    // radius of the PieView Circle
    private var circleRadius: CGFloat {
        return min(bounds.size.width, bounds.size.height) / 2 * scale
    }
    
    
    // redraw when device is rotated
    override func layoutSubviews() {
        super.layoutSubviews()
        self.setNeedsDisplay()
    }
    
    var arcWidth:CGFloat = 10.0
    var arcColor = UIColor.greenColor()
    var arcBackgroundColor = UIColor.blackColor()
    
    override func drawRect(rect: CGRect)
    {
        
        
        let fullCircle = 2.0 * CGFloat(M_PI) // draws the full circle
        
        let start:CGFloat = -0.25 * fullCircle
        // get the propertion of completed task and draw the arc up to that point
        let c =  dataSource?.completedtask(self)
        let end:CGFloat = CGFloat(c!) * fullCircle + start
        
        let context = UIGraphicsGetCurrentContext()
        // Full Circle
        CGContextSetLineWidth(context, arcWidth)
        CGContextSetLineCap(context, .Round)
        CGContextSetFillColorWithColor(context, arcBackgroundColor.CGColor)
        CGContextAddArc(context, circleCenter.x, circleCenter.y, circleRadius, 0, fullCircle, 0)
        let l = UIColor.redColor()
        CGContextSetFillColorWithColor(context, l.CGColor)
        CGContextFillPath(context)
        CGContextSetFillColorWithColor(context, arcColor.CGColor)
        CGContextMoveToPoint(context, circleCenter.x, circleCenter.y)
        // Draw the arc to represent the finished task
        CGContextAddArc(context, circleCenter.x, circleCenter.y, circleRadius, start, end, 0)
        CGContextFillPath(context)
        
        // Draw circle boundary
        let circleBoundary = UIBezierPath(
            arcCenter: circleCenter,
            radius: circleRadius,
            startAngle: 0,
            endAngle: CGFloat(2*M_PI),
            clockwise: true
        )
        
        circleBoundary.lineWidth = lineWidth
        color.set()
        circleBoundary.stroke()
        
    }
    
}

 