//
//  TaskDetailVC.swift
//  TODoList
//  TODoList App : COS 470: Final Project
//  Created by Smita Sukhadeve on 5/2/16.
//  Copyright © 2016 USM. All rights reserved.
//

import UIKit
/*
This ViewController is responsible for showing the detail about selected task in the tableView
*/
class TaskDetailVC: UIViewController, UITextFieldDelegate, UINavigationControllerDelegate {
       var task: Task?
       let formatter:NSDateFormatter = NSDateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Handle the text field’s user input through delegate callbacks.
        taskTextField.delegate = self
        taskDetailField.delegate = self
        // Do any additional setup after loading the view.
      
        if let task = taskDetailset {
            navigationItem.title = task.taskName
            taskTextField.text   = task.taskName
            taskDetailField.text = task.taskDesc
            formatter.dateStyle = .MediumStyle
            formatter.timeStyle = .MediumStyle
            formatter.locale = NSLocale(localeIdentifier: "en_US")
            if let startD = task.taskStartDate {
                taskStartDate.text =  formatter.stringFromDate(startD)
            }
            
            if let finishD = task.taskFinishtDate {
                  taskEndDate.text =  formatter.stringFromDate(finishD)
            }
          
            sliderStatus.text = String(Int(task.completionStatus))
            completionSlider.value = Float(task.completionStatus)
            taskTextField.userInteractionEnabled = false
            taskDetailField.userInteractionEnabled = false
            taskStartDate.userInteractionEnabled = false
            taskEndDate.userInteractionEnabled = false
        }
    }

    
    @IBOutlet weak var taskStartDate: UITextField!
    @IBOutlet weak var taskEndDate: UITextField!
    
    var taskDetailset: Task? {
        get {
        return self.task!
        }set {
        
        self.task = newValue
        }
    }
    

    @IBOutlet weak var completionSlider: UISlider!
    
    @IBOutlet weak var sliderStatus: UILabel!
    
    // User can use the slider to mark % completion of the tasks
    @IBAction func sliderMoved(sender: UISlider) {
        
        let currentValue = Int(sender.value)
        sliderStatus.text = "\(currentValue)"
        task?.completionStatus = Double(currentValue)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBOutlet weak var taskLabel: UILabel!
    @IBOutlet weak var taskDetail: UILabel!
    @IBOutlet weak var taskTextField: UITextField!
    @IBOutlet weak var taskDetailField: UITextField!

}
