//
//  Task.swift
//  TODoList
//  Created by Smita Sukhadeve
//  Copyright © 2016 USM. All rights reserved.
//
import Foundation
import MapKit

// Data structure for Task Model
//  We cretate task and save it in the file


class Task: NSObject, NSCoding {
    
    
    // MARK: Archiving Paths
    static let DocumentsDirectory = NSFileManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.URLByAppendingPathComponent("tasks")
    
    var taskName: String  // This is not optional. if blank it is "unknown"
    var taskDesc: String?  // description of the task. to add additional notes. optional
    var taskStartDate: NSDate?  // optional
    var taskFinishtDate: NSDate?  // optional
    var completionStatus: Double  // it will be shown as number from 1 to 100 % : default 0%
   var location: String?  // To add reminder based on location: We might make dictionary string: Coordinate later //additional
   var photo: UIImage?  //  optional
    
    
    // MARK: Types
    
    struct PropertyKey {
        
        static let taskNameKey =  "taskName"
        static let taskDescKey = "taskDesc"
        static let taskStartDateKey = "taskStartDate"
        static let taskFinishtDateKey = "taskFinishtDate"
        static let completionStatusKey = "completionStatusKey"
        static let locationKey = "location"
        static let photoKey = "photo"
    }
    
    
    // MARK: Initialization
    init?(taskName: String, taskDesc: String?, taskStartDate: NSDate?, taskFinishDate: NSDate?, completionStatus: Double
        ,location: String?, photo: UIImage?) {
            
            // Initialize stored properties.
            self.taskName = taskName
            self.taskDesc =  taskDesc
            self.taskStartDate = taskStartDate
            self.taskFinishtDate = taskFinishDate
            self.completionStatus = completionStatus
            self.location =  location
            self.photo = photo
    }
    
    
    
    // MARK: NSCoding
    
    func encodeWithCoder(aCoder: NSCoder) {
        
        aCoder.encodeObject(taskName, forKey: PropertyKey.taskNameKey)
        aCoder.encodeObject(taskDesc, forKey: PropertyKey.taskDescKey)
        aCoder.encodeObject(location, forKey: PropertyKey.locationKey)
        aCoder.encodeDouble(completionStatus, forKey: PropertyKey.completionStatusKey)
        aCoder.encodeObject(taskStartDate, forKey: PropertyKey.taskStartDateKey)
        aCoder.encodeObject(taskFinishtDate, forKey: PropertyKey.taskFinishtDateKey)
        aCoder.encodeObject(photo, forKey: PropertyKey.photoKey)
        
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        
        // to cast optional property of Task, use conditional cast.
        
        let taskName = aDecoder.decodeObjectForKey(PropertyKey.taskNameKey) as! String
        let taskDesc = aDecoder.decodeObjectForKey(PropertyKey.taskDescKey) as?  String
        let location = aDecoder.decodeObjectForKey(PropertyKey.locationKey) as? String
        let completionStatus = aDecoder.decodeDoubleForKey(PropertyKey.completionStatusKey)
        let taskStartDate = aDecoder.decodeObjectForKey(PropertyKey.taskStartDateKey) as? NSDate
        let taskFinishtDate = aDecoder.decodeObjectForKey(PropertyKey.taskFinishtDateKey) as? NSDate
        let photo = aDecoder.decodeObjectForKey(PropertyKey.photoKey) as? UIImage
        
        //designated initializer
        
        self.init(taskName: taskName,
            taskDesc: taskDesc,
            taskStartDate: taskStartDate,
            taskFinishDate: taskFinishtDate,
            completionStatus: completionStatus,
            location: location,
            photo: photo
        )
    }
    
}







