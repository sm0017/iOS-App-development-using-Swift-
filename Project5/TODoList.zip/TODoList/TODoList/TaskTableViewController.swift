
//  TaskTableViewController.swift
//  TODoList App : COS 470: Final Project
//  Created by Smita Sukhadeve
//  Copyright © 2016 USM. All rights reserved.
//
/*

Support functionalities: Iphone
--*******************************************************************************************
This App contains multiple screens. Below are the three main screens :

-Task Screen : Table View

    -- Task Creation screen
    -- Reminder creation screen : User can create reminders.
    -- Location reminder creation screen using mapView

    -- Task detail Screen
        -- User can mark % completed using the slider.
        -- Edit functinality
   ---  If the task is mark as 100% it will apper in green color in table view
   --- task will be sorted by as per start date
   --- The due date will appear in red if the Due Date is in the past or else in black


-Reminder Screen : Table View
    -- delete functionality on swipe
    -- Deleting reminder delete only created reminder. DO not delete the task
    -- View reminder Details screen
    -- Created reminder also can verified from reminder app

- Graph Screen : Custom View
    -- Shows custom Pie chart showing completed task % in green and Unifinished task in Red

-- Multiple View controllers work together using Tab bar and navigation controllers
-- Support persistent store
-- Used Custom View, delegation, Unwind Segues
-- Used frameworks EventKit, MapKit, CoreLocation, UIKIt
--*******************************************************************************************
Proposed Functionalities:
1. Create task : Done
2. Add reminder : Done
3.% completion status : Done
4. reward point: Did not added. I felt like this isn't that important As scope of project got complecated due to multiple Views
5. Location and Map functionality : Additional: Locations are added for monitoring. But For some reason CLlocationManager 'DidEnter' is not getting invoked.
6.Graphic Represenation: Initially thought of using Bar chart to show week day status. Later, I felt It makes more sense to show complted 
uncompleted task using Pie Chart. Drawing complex Custom View was kind of struggling so decided to draw simple Pie Chart Custom view
*/

/*
This is the tableViewController is responsible for Displaying all the task.
Adding new task using "+" button
Detail View of each task
Delete created task
*/

import UIKit
import MapKit
import CoreLocation
import EventKit

class TaskTableViewController: UITableViewController, CLLocationManagerDelegate {
    
    
    var locationManager = CLLocationManager() // location manager for notifying location based reminders
    var locations = [Location]()  // locations datasource for the tableview
    var monitoredRegions = [CLCircularRegion]()  // Monitored regions:  list of location for which reminders are added
    var tasks = [Task]()
    var taskDB = TaskDb()
    var sortByDate = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        // Request permission from user to use Location Service
        locationManager.requestAlwaysAuthorization()
        
        // Load the saved tasks from the persistent store and load the data require for tableView
        let savedTask = TaskDb().loadtasks()
        if savedTask != nil {
            if !savedTask!.isEmpty {
                tasks  = savedTask!
            }
        }
        
        if let l = taskDB.loadLocations() {
            locations = l
        }
        addAllregionForMonitoring(locations, locationManager: locationManager)
        
        refreshTableView()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        self.navigationItem.leftBarButtonItem = self.editButtonItem()
        
    }
    
    // Function to refresh the tableView whenever there are any changes in the datasouce
    // Arranges all the tasks by Start Date
    func refreshTableView() {
        self.tasks.sortInPlace() {
            if $0.taskStartDate != nil && $1.taskStartDate != nil {
                if $0.taskStartDate!.compare($1.taskStartDate!) == NSComparisonResult.OrderedAscending {
                    sortByDate = true
                }else  { sortByDate = false }
            }
            return sortByDate
        }
        tableView.reloadData()
    }
    
    // MARK: - Table view data source
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return tasks.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("taskCell", forIndexPath: indexPath)
        // Configure the cell...
        let task = tasks[indexPath.row]
        
        cell.textLabel?.text = task.taskName
        
        // Logic to format the NSDate
        let formatter:NSDateFormatter = NSDateFormatter()
        formatter.dateStyle = .MediumStyle
        formatter.timeStyle = .MediumStyle
        formatter.locale = NSLocale(localeIdentifier: "en_US") 
        
        // display Due Date if its associated with the created task else blank
        // If Due Date is in past, Text color is red else Black
        if let dueDate = task.taskFinishtDate{
            cell.detailTextLabel?.text = "Due Date: " + formatter.stringFromDate(dueDate)
            if dueDate.compare(NSDate()) == NSComparisonResult.OrderedAscending {
                cell.detailTextLabel?.textColor = UIColor.redColor()
            }
        }else{
            cell.detailTextLabel?.text = " "
        }
        
        // Display 100% completed task in Green
        if task.completionStatus == Double(100) {
            cell.backgroundColor =  UIColor.greenColor()
        }else {
            cell.backgroundColor =  UIColor.groupTableViewBackgroundColor()
        }
        return cell
    }
    
    
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tasks.removeAtIndex(indexPath.row)
            // Save the changes
            taskDB.savetasks(tasks)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        }
    }
    
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
        
    }
    
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    
    
    @IBAction func cancelToTaskViewController(segue: UIStoryboardSegue) {
        
        // When user click Cancel, control comes back here
         refreshTableView()
    }
    
    
    @IBAction func saveTaskDetail(segue: UIStoryboardSegue) {
        let task =  taskDB.loadtask()
        tasks.append(task!)
        refreshTableView()
    }
    
    
    
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    // This View  leads to two new screens using the segues. 1. Add New Taks and 2. Show details
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        // if it is TaskDetail View
        if segue.identifier == "showDetails" {
            let taskDetailVC = (segue.destinationViewController as! UINavigationController).topViewController as! TaskDetailVC
            
            // Get the cell that generated this segue.
            if let selectedTaskCell = sender {
                let indexPath = tableView.indexPathForCell(selectedTaskCell as! UITableViewCell)!
                let selectedTask = tasks[indexPath.row]
                taskDetailVC.taskDetailset = selectedTask
            }
        }// If it new task View
        else if segue.identifier == "add task" {
            
        }
    }
    
    // UnWind Segues to come back from the NewTaskView Screen, LocationViewController, TaskDetailVC to TaskTable View
    @IBAction func unwindToTaskList(sender: UIStoryboardSegue) {
       
        if let sourceViewController = sender.sourceViewController as? NewTaskViewController, task = sourceViewController.task {
            let newIndexPath = NSIndexPath(forRow: tasks.count, inSection: 0)
            tasks.append(task)
            tableView.insertRowsAtIndexPaths([newIndexPath], withRowAnimation: .Bottom)
          }// We used Unwind segue to get the location from the LocationViewController's MapView
           // We also get the task so we can save cretaed task and reload tableView datasource
        else if let sourceViewController = sender.sourceViewController as? LocationViewController, task = sourceViewController.task ,
            location = sourceViewController.location{
                let newIndexPath = NSIndexPath(forRow: tasks.count, inSection: 0)
                task.location = location.name ?? ""
                tasks.append(task)
                locations.append(location)
                tableView.insertRowsAtIndexPaths([newIndexPath], withRowAnimation: .Bottom)
        }else if let sourceViewController = sender.sourceViewController as? TaskDetailVC, _ = sourceViewController.task
        {
         //  We don't have to do anything here
    
        }
        
        // To save the Tasks changes after creating new tasks/ changing the completion status. Refresh Table View after the saving all the changes
        taskDB.savetasks(tasks)
        taskDB.saveLocations(locations)
        refreshTableView()
    }
    
   
    // MARK : Methods required for creating Location Based reminders
    
    // MARK : Location Manager delegates method. Add All the  regions to be monitored
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
     
        // if User given us permission for LocationService, then add all the region for  to monitor so 
        // That we can display alert for task reminder when user enter those location
        if status == .AuthorizedAlways || status == .AuthorizedWhenInUse {
            if let locations = taskDB.loadLocations(){
                addAllregionForMonitoring(locations, locationManager: locationManager)}
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        
        // Load all the location added During for creating the location Based reminders
        if let l = taskDB.loadLocations() {
            locations = l
        }
        addAllregionForMonitoring(locations, locationManager: locationManager)
        refreshTableView()
    }
    
    
    func addAllregionForMonitoring(locations: [Location], locationManager : CLLocationManager) {
        if !locations.isEmpty {
            for location in locations{
                let region = convertEachRegion(location)
                locationManager.startMonitoringForRegion(region)
            }
        }
    }
    
    // This function convert each location to CLcircular region which will be monitored by CLLocation Manager
    // We need to convert location to CLCircular Regions inorder to use CLLOcation Manager monitor service
    func convertEachRegion (location: Location) -> CLCircularRegion {
        let c = CLLocationCoordinate2DMake(location.latitude, location.longitude)
        let cr  = CLCircularRegion(center: c, radius: 200, identifier: location.name)
        return cr
    }
    
    
    // Function get called when User finds any of the monitored locations
    func handleFoundMonitoredRegions(region: CLCircularRegion, viewController: UIViewController, locationManager: CLLocationManager) {
        // We show an alert if application is active
        if UIApplication.sharedApplication().applicationState == .Active {
            showLocationAlert(region, viewController: viewController, locationManager: locationManager)
        }
    }
    
    // To verify if the monitoring has started or not for the added Regions
    func locationManager(manager: CLLocationManager, didStartMonitoringForRegion region: CLRegion) {
         // Method to Verify we have started monitoring location for location based reminder
        print(" start monitoring location" + region.identifier + " to display location based reminder tasks ")
    }
    
    // Method get called when User enter one of the region we are monitoring for displaying the location based reminder.
    func locationManager(manager: CLLocationManager, didEnterRegion region: CLRegion) {
        
        // Stop Monitoring the location after reminder has been displayed
        if region is CLCircularRegion {
            monitoredRegions.append(region as! CLCircularRegion)
            locationManager.stopMonitoringForRegion(region)
        }
        
        //We remove location from the monitored region
        if !monitoredRegions.isEmpty {
            while !monitoredRegions.isEmpty {
                let cr = monitoredRegions.removeFirst()
                handleFoundMonitoredRegions(cr, viewController: self, locationManager: manager)
            }
        }
    }
    
    // MARK: shows alert whenever user find any monitored locations and update the VisitedDate accordingl
    func showLocationAlert(region: CLCircularRegion, viewController: UIViewController, locationManager: CLLocationManager) {
        
        let title = "You have reminder set up for this location \(region.identifier)"
        var message = "Could not find task detail associated with it"
    
           // If you have found the location , show task detail to user as message in alert
        if !self.locations.isEmpty {
            for foundLocation in locations {
                
                if foundLocation.name == region.identifier {
                    let linkedTask = foundLocation.task
                    message =  "you have to complete" + linkedTask.taskName
                }
            }
        }
        let alertCtrl  = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        // Added Cancel Action
        let cancelAction: UIAlertAction = UIAlertAction(title: "Cancel", style: .Cancel) { action -> Void in
            // Do Nothing
        }
        alertCtrl.addAction(cancelAction)
        
        // Added Ok action
        let markVisited: UIAlertAction = UIAlertAction(title: "OK", style: .Default) { action -> Void in
            
            // If User said Ok, we will remove the location based reminder
            if !self.locations.isEmpty {
                for foundLocation in self.locations {
                    
                    if foundLocation.name == region.identifier {
                        
                        let foundLocIndex = self.locations.indexOf(foundLocation)
                        if foundLocIndex != nil {
                            self.locations.removeAtIndex(foundLocIndex!)
                            self.taskDB.saveLocations(self.locations)
                        }
                    }
                }
            }
        }
        
        alertCtrl.addAction(markVisited)
        if viewController.presentedViewController == nil {
            viewController.presentViewController(alertCtrl, animated: true, completion: nil)
        }
    }

    
    func locationManager(manager: CLLocationManager, monitoringDidFailForRegion region: CLRegion?, withError error: NSError) {
        print("\(error)")
    }
}

