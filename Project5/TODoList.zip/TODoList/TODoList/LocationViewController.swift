//
//  LocationViewController.swift
//  Created by Smita Sukhadeve
//  Copyright © 2016 USM. All rights reserved.
// TODoList App : COS 470: Final Project

//

/*

This View is Responsible for creating the location based reminder
-- Search location on map
-- if the location is found, click the right callOut accessory button to create the location based reminder
-- We link associated task with location
*/

import UIKit
import MapKit

class LocationViewController: UIViewController, UISearchBarDelegate, MKMapViewDelegate, CLLocationManagerDelegate{
    
    var task: Task?
    var location: Location?
    let locationManager = CLLocationManager()
    var annotation:MKAnnotation!
    var error:NSError!
    var pointAnnotation:MKPointAnnotation!
    var pinAnnotationView:MKPinAnnotationView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        let coordinate:CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: 34.03, longitude: 118.14)
        let span = MKCoordinateSpanMake(100, 80)
        let region = MKCoordinateRegionMake(coordinate, span)
        self.mapView.setRegion(region, animated: true)
    }
    
    // Task is get assigned while preparing for segue in NewTaskViewController so that we can link the create reminder 
    // WIth associtated task
    var taskDetailset: Task? {
        get {
            return self.task!
        }set {
            self.task = newValue
        }
    }
    
    
    @IBOutlet weak var mapView: MKMapView!
        {
        didSet {
            mapView.delegate = self
        }
    }
    // search controller to search the location
    var searchController:UISearchController!
    
    @IBAction func searchLocation(sender: UIBarButtonItem) {
        searchController = UISearchController(searchResultsController: nil)
        searchController.hidesNavigationBarDuringPresentation = false
        self.searchController.searchBar.delegate = self
        presentViewController(searchController, animated: true, completion: nil)
    }
    var localSearchRequest:MKLocalSearchRequest!
    var localSearch:MKLocalSearch!
    var localSearchResponse:MKLocalSearchResponse!
    
    // When the search button is click
    func searchBarSearchButtonClicked(searchBar: UISearchBar){
        searchBar.resignFirstResponder()
        dismissViewControllerAnimated(true, completion: nil)
        if self.mapView.annotations.count != 0{
            annotation = self.mapView.annotations[0]
            self.mapView.removeAnnotation(annotation)
        }
        //initiates a map-based search operation
        localSearchRequest = MKLocalSearchRequest()
        // Set the search bar text as search string
        localSearchRequest.naturalLanguageQuery = searchBar.text
        // start search
        localSearch = MKLocalSearch(request: localSearchRequest)
        localSearch.startWithCompletionHandler { (localSearchResponse, error) -> Void in
            
            if localSearchResponse == nil{
                let alertController = UIAlertController(title: nil, message: "We could Not find the place", preferredStyle: UIAlertControllerStyle.Alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default, handler: nil))
                self.presentViewController(alertController, animated: true, completion: nil)
                return
            }
            
            self.pointAnnotation = MKPointAnnotation()
            self.pointAnnotation.title = searchBar.text
            self.pointAnnotation.coordinate = CLLocationCoordinate2D(latitude: localSearchResponse!.boundingRegion.center.latitude,
                                                                    longitude: localSearchResponse!.boundingRegion.center.longitude)
            self.pinAnnotationView = MKPinAnnotationView(annotation: self.pointAnnotation, reuseIdentifier: nil)
            self.mapView.centerCoordinate = self.pointAnnotation.coordinate
            self.mapView.addAnnotation(self.pinAnnotationView.annotation!)
        }
    }
    
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        var view = mapView.dequeueReusableAnnotationViewWithIdentifier("locations")
        if view == nil {
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "locations")
            view?.canShowCallout = true
        }
        view?.annotation = annotation
        view!.rightCalloutAccessoryView = nil
        let infobtn = UIButton(type: UIButtonType.DetailDisclosure) as UIButton // button with info sign in it
        view?.rightCalloutAccessoryView = infobtn
        return view
    }
    
    // MARK: CallOut alert function
    func mapView(mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        var title: String = " "
        var message: String = " "
        if view.annotation is MKPointAnnotation{
            title = "Do you want to add Reminder?"
            message = "  "
        }
        let alertCtrl  = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        
        //Create Cancel Action
        let cancelAction: UIAlertAction = UIAlertAction(title: "Cancel", style: .Cancel) { action -> Void in
        }
        alertCtrl.addAction(cancelAction)
        
        // Create OK action to mark place as visited
        let markLocation: UIAlertAction = UIAlertAction(title: "OK", style: .Default) { action -> Void in
            
            let c = view.annotation?.coordinate
            let name = view.annotation?.title
            self.location = Location(name: name!!, latitude: (c?.latitude)!, longitude: (c?.longitude)!, task: self.task!)
             print("getting coordinates for \(self.location?.name)")
             print("location latitude  is : \(self.location!.latitude)")
             print("location longitude is : \(self.location!.longitude)")
        }
        alertCtrl.addAction(markLocation)
        if self.presentedViewController == nil {
            self.presentViewController(alertCtrl, animated: true, completion: nil)
        }
    }
}

