//
//  PieViewController.swift
//  Created by Smita Sukhadeve
//  TODoList App : COS 470: Final Project
//  Copyright © 2016 USM. All rights reserved.
//

/*

This view is responsible for drawing the custom PieView which shows in 
% completed task in Green and %Unfinished tasks in Red in  the pie Chart
Also act as delgate for Pie View. Implement CircleViewDataSource protocol by implementing completedtask() 
*/

import UIKit

class PieViewController: UIViewController, CircleViewDataSource {
    var finishedTask = 0.0
    var unfinishedTask =  0.0
    var tasks = [Task]()
    override func viewDidLoad() {
        super.viewDidLoad()
        getFinishedUnfinshedTasks()
        // Display the % in the PieView
        completedTask.text = " \(Int(finishedTask * 100)) %"
        uncompletedTask.text = "\(Int(100 - finishedTask * 100))%"
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func proprtionArry(sender: PieView) -> ([Double]?, [UIColor]?) {
        let fractions = [0, finishedTask]
        let x: [UIColor] = [UIColor.greenColor(), UIColor.redColor()]
        return (fractions, x)
        
    }
    
    
    // Pie View Delegate method implemented here. It gives the proportion for drawing the pie Chart
    func completedtask(sender: PieView)-> Double{
        let x = finishedTask
        let y = Double(round(10*x)/10)
        return y
    }
    
    @IBOutlet weak var pieView: PieView! {
        didSet {
            pieView.dataSource = self
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        getFinishedUnfinshedTasks()
        completedTask.text = " \(Int(finishedTask * 100)) %"
        uncompletedTask.text = "\(Int(100 - finishedTask * 100))%"
        pieView.setNeedsDisplay()
    }
    
    @IBOutlet weak var completedTask: UILabel!
    @IBOutlet weak var uncompletedTask: UILabel!
    
    
    //Method to get the proprtion of unfinished and finished tasks
    func getFinishedUnfinshedTasks () {
        finishedTask = 0.0
        unfinishedTask =  0.0
        
        if let t = TaskDb().loadtasks() {
            tasks = t
        }
        // Identify Finished task and Unfinished task using the completion Status
        if tasks.count > 0 {
            for savedtask in tasks  {
                if savedtask.completionStatus == Double(100) {
                    finishedTask = finishedTask + 1
                }else {
                    unfinishedTask = unfinishedTask + 1
                }
            }
        } else {
            finishedTask = 0.0
            unfinishedTask = 0.0
        }
        // Get the proportion of finished and Unfinished tasks
        if tasks.count > 0 {
            finishedTask = finishedTask /  Double(tasks.count)
            unfinishedTask = unfinishedTask /  Double(tasks.count)
            
        }else {
            finishedTask = 0.0
            unfinishedTask = 0.0
        }
    }
}

extension Double {
    /// Rounds the double to decimal places value
    func roundToPlaces(places:Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return round(self * divisor) / divisor
    }
}

