//
//  Location.swift
//  HuskyHuntProject4
//  Created by Smita Sukhadeve on 4/1/16.
//  Copyright © 2016 USM. All rights reserved.
//


/*

This is Data Structure to save the location based task reminders
Each location based task uniquelly identified by combination of (location name and task name).
Supports NSCoding standard to saved locationBased task into the file

*/

import Foundation
import MapKit

// Model data structre

class Location: NSObject, NSCoding {
    
    // MARK: Archiving Paths
    static let DocumentsDirectory = NSFileManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.URLByAppendingPathComponent("locations")
    
    var name: String
    var latitude: CLLocationDegrees
    var longitude: CLLocationDegrees
    var task: Task
    
    struct PropertyKey {
        
        static let nameKey = "name"
        static let latitudeKey = "latitude"
        static let longitudeKey = "longitude"
        
        static let taskKey = "taskKey"
    }
    
    
    init(name: String, latitude: CLLocationDegrees, longitude:CLLocationDegrees, task: Task) {
        self.name = name
        self.latitude = latitude
        self.longitude = longitude
        self.task = task
        
    }
    
    //MARK : NSCoding encoder and decoder required for the persistent storage
    
    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(name, forKey: PropertyKey.nameKey)
        aCoder.encodeDouble(latitude, forKey: PropertyKey.latitudeKey)
        aCoder.encodeDouble(longitude, forKey: PropertyKey.longitudeKey)
        aCoder.encodeObject(task, forKey: PropertyKey.taskKey)
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        let name = aDecoder.decodeObjectForKey(PropertyKey.nameKey) as! String
        let latitude = aDecoder.decodeDoubleForKey(PropertyKey.latitudeKey)
        let longitude = aDecoder.decodeDoubleForKey(PropertyKey.longitudeKey)
        let task = aDecoder.decodeObjectForKey(PropertyKey.taskKey) as! Task
        self.init(name: name, latitude: latitude, longitude:longitude, task: task)
    }
    
    
}


