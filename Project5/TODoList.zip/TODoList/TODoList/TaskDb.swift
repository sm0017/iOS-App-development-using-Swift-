//
//  TaskDb.swift
//  TODoList
//  Created by Smita Sukhadeve
//  Copyright © 2016 USM. All rights reserved.
//

/*
This Class contains all the database/permanet storage functions which include loading data to the file,
saving it, fecting tasks and location based reminders etc.
*/

import UIKit

class TaskDb {
    
    // MARK: Save to the files
    
    func savetasks(tasks: [Task]) {
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(tasks, toFile: Task.ArchiveURL.path!)
        if !isSuccessfulSave {
            print("Failed to save tasks...")
        }
    }
    
    // unarchive from the file
    func loadtasks() -> [Task]? {
        return NSKeyedUnarchiver.unarchiveObjectWithFile(Task.ArchiveURL.path!) as? [Task]
    }
    
    // unarchive from the file
    func loadtask() -> Task? {
        return NSKeyedUnarchiver.unarchiveObjectWithFile(Task.ArchiveURL.path!) as? Task
    }
    
    func savetask(task:Task ) {
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(task, toFile: Task.ArchiveURL.path!)
        if !isSuccessfulSave {
            print("Failed to save tasks...")
        }
    }
    
    
    // Load the locations from the saved File
    func loadLocations() -> [Location]? {
        return (NSKeyedUnarchiver.unarchiveObjectWithFile(Location.ArchiveURL.path!) as? [Location])
        
    }
    
    //Saves the locations at given file path
    func saveLocations(locations: [Location]) {
        
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(locations, toFile: Location.ArchiveURL.path!)
        if !isSuccessfulSave {
            print ("failed to save Locations")
        }
    }
    
    func searchTaskByName(reminderTitle: String?, tasks: [Task]) -> Task?{
        for task in tasks  {
            
            if task.taskName == reminderTitle {
                return task
            }
            
        }
        
        return nil
    }
}

