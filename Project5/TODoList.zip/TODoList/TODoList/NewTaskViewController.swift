//
//  NewTaskViewController.swift
//  Final Project : TODo App
//  Created by Smita Sukhadeve
//  Copyright © 2016 USM. All rights reserved.
//  TODoList App : COS 470: Final Project

import UIKit
import EventKitUI
import EventKit

/*
This view controller is reesponsible for controlling the creation of new tasks
// saving the new task: TaskName is required property to save the task
//Adding reminder which could be one of TimeBased or location based using the Reminder and Location button respectivelly

*/

class NewTaskViewController: UIViewController, UITextFieldDelegate, UINavigationControllerDelegate{
    
    var task: Task?
    var datePicker: UIDatePicker!
    var datePickerEnd: UIDatePicker!
    let datePickerView:UIDatePicker = UIDatePicker()
    var appDelegate: AppDelegate?
    
    @IBOutlet weak var taskNameTextField: UITextField!
    @IBOutlet weak var savebutton: UIBarButtonItem!
    @IBOutlet weak var taskDetailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        savebutton.enabled = false
        taskNameTextField.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // Action to display DatePicker to select the start date
    @IBAction func editingStartDate(sender: UITextField) {
                 self.startDatePickerValueChanged()
    }
    
    // Action to display DatePicker to select the end date
    @IBAction func editingEndDate(sender: UITextField) {
     endDatePickerValueChanged()
    }
 
    
    func showDatePicker() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        startTextField.inputView = datePicker
        
    }
    
    @IBOutlet weak var startTextField: UITextField!
    @IBOutlet weak var endDateField: UITextField!
    
    // Set the startDate text Field value to selected start Date
    func startDatePickerValueChanged() {
        
        DatePickerDialog().show("DatePicker", doneButtonTitle: "Done", cancelButtonTitle: "Cancel", datePickerMode: .DateAndTime) {
            (date) -> Void in
            self.startTextField.text = "\(date)"
            self.startDate = date
        }
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        checkValidTaskName()
        navigationItem.title = taskNameTextField.text
    }
    var startDate: NSDate?
    var endDate: NSDate?
    
    // set the selected value of end date
    func endDatePickerValueChanged() {
        
        DatePickerDialog().show("DatePicker", doneButtonTitle: "Done", cancelButtonTitle: "Cancel", datePickerMode: .DateAndTime) {
            (date) -> Void in
            self.endDateField.text  = "\(date)"
            self.endDate = date
        }
        
    }
    
    // MARK: UITextFieldDelegate
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
     
        // If user save buttion save the tasks
        if savebutton === sender {
            var taskDesc: String = " "
            let taskName = taskNameTextField.text ?? ""
            if let t = taskDetailTextField.text {
                taskDesc = t
            }
            task = Task(taskName: taskName, taskDesc: taskDesc,
                taskStartDate: startDate, taskFinishDate: endDate,
                completionStatus: Double(0.0), location: nil, photo: nil)
         }// if user want to create the location based reminder take then to Location View Controller screen.
        else if segue.identifier == "add location" {
            let rmc = (segue.destinationViewController as! UINavigationController).topViewController as! LocationViewController
            let taskName = taskNameTextField.text ?? ""
            let taskDesc = taskDetailTextField.text ?? " "
            task = Task(taskName: taskName, taskDesc: taskDesc,
                taskStartDate: startDate, taskFinishDate: endDate,
                completionStatus: Double(0.0), location: nil, photo: nil)
            rmc.taskDetailset = task
        }
    }
    
    // Save button will be disable if user do not type task Name
    // Task Name is required property. User need to enter the task name to save the task
    @IBAction func saveButtonPressed(sender: UIBarButtonItem) {
        checkValidTaskName()
    }
    
    // Enable the save button only when taskName field is not empty
    func checkValidTaskName() {
        // Disable the Save button if the text field is empty.
        let text = taskNameTextField.text ?? ""
        if !text.isEmpty {
            savebutton.enabled = true
        }
    }
    // If user clicks the reminder button before saving the tasks, create the reminder
    @IBAction func setReminder(sender: UIButton) {
        appDelegate = UIApplication.sharedApplication().delegate
            as? AppDelegate
        
        if appDelegate!.eventStore == nil {
            appDelegate!.eventStore = EKEventStore()
        }
        
        appDelegate!.eventStore!.requestAccessToEntityType(EKEntityType.Reminder) {
            (granted: Bool, error: NSError?) -> Void in
            if !granted {
                print("error while creating reminder")
            }else {
                if (self.appDelegate!.eventStore != nil) {
                    self.createReminder()
                    dispatch_async(dispatch_get_main_queue(), {
                        self.showAlert(self)
                    })
                }
            }
        }
    }
    
    // This method create reminders and save those reminder in the user Default Calandar
    // We also add the alarm on Due time to remind user about the due Date
    
    func createReminder() {
        let reminder = EKReminder(eventStore: appDelegate!.eventStore!)
        reminder.title = taskNameTextField.text!
        // get an instance of the EKEventStore class to access the default Calendar database
        
        reminder.calendar = appDelegate!.eventStore!.defaultCalendarForNewReminders()
        reminder.startDateComponents = dateComponentFromNSDate(startDate!)
        
        // add alarm for the created reminder
        if let e = endDate {
            
            let alarm = EKAlarm(absoluteDate: e)
            reminder.addAlarm(alarm)
        }
        let _: NSError?
        do {
            try appDelegate!.eventStore?.saveReminder(reminder, commit: true)
        } catch {
            print("\(error)")
        }
    }
    
    func dateComponentFromNSDate(date: NSDate)-> NSDateComponents{
        let calendarUnit: NSCalendarUnit = [.Hour, .Day, .Month, .Year]
        let dateComponents = NSCalendar.currentCalendar().components(calendarUnit, fromDate: date)
        return dateComponents
    }
    
    // Show alert if the reminder is successfully crared
    func showAlert(viewController: UIViewController) {
        
        let title = "Successfully created Reminder!"
        let message = " "
        let alertCtrl  = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        // Added Ok action
        let markOk: UIAlertAction = UIAlertAction(title: "OK", style: .Default) { action -> Void in
         // Do nothing
        }
        
        alertCtrl.addAction(markOk)
        if viewController.presentedViewController == nil {
            viewController.presentViewController(alertCtrl, animated: true, completion: nil)
        }
    }
    
}
