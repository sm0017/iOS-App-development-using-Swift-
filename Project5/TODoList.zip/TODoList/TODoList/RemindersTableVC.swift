//
//  RemindersTableVC.swift
//
//  TODoList App : COS 470: Final Project
//  Created by Smita Sukhadeve
//  Copyright © 2016 USM. All rights reserved.
//

/*
This View is Responsible for Shwoing the created Reminder deatils
and task associated with it
// User can also delete the created task
We use EventKit framework to retrive the created reminders
*/
import UIKit
import EventKit

class RemindersTableVC: UITableViewController {
    
    var appDelegate: AppDelegate?
    var reminders = [EKReminder]()
    var tasks = [Task]()
    let taskDb = TaskDb()
    override func viewDidLoad() {
        super.viewDidLoad()
        // fetch the reminders from the eventStore
        
        fetchReminders()
        // Load all the tasks
        if let t  = taskDb.loadtasks() {
            tasks = t
        }
        // load the data
        self.tableView.reloadData()
        self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        fetchReminders()
        if let t  = taskDb.loadtasks() {
            tasks = t
        }
        self.tableView.reloadData()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return reminders.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("reminderCell", forIndexPath: indexPath)
        // Configure the cell...
        let reminder = reminders[indexPath.row]
        cell.textLabel?.text = reminder.title
        
        let formatter:NSDateFormatter = NSDateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        
        if let dueDate = reminder.startDateComponents?.date{
            cell.detailTextLabel?.text = formatter.stringFromDate(dueDate)
        }else{
            cell.detailTextLabel?.text = " "
        }
        
        return cell
    }
    
    
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            let removedreminder =  reminders.removeAtIndex(indexPath.row)
            do {
                try appDelegate!.eventStore?.removeReminder(removedreminder, commit: true)
            } catch {
                print("\(error)")
            }
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        }
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showReminders" {
            
            let taskDetailVC = (segue.destinationViewController as! UINavigationController).topViewController as! TaskDetailVC
            
            // Get the cell that generated this segue.
            // Get the task associted with selected Reminder and show the detail
            if let selectedTaskCell = sender {
                let indexPath = tableView.indexPathForCell(selectedTaskCell as! UITableViewCell)!
                let reminder = reminders[indexPath.row]
                let task = taskDb.searchTaskByName(reminder.title, tasks: tasks)
                if task != nil {
                    taskDetailVC.taskDetailset = task!
                }
            }
        }
        else if segue.identifier == "add task" {
            
        }
    }
    
    // Function to fetch the created reminders
    // We fetch reminder from the eventStore for the reminders
    
    func fetchReminders(){
        self.reminders = [EKReminder]()
        appDelegate = UIApplication.sharedApplication().delegate
            as? AppDelegate
        
        if appDelegate!.eventStore == nil {
            appDelegate!.eventStore = EKEventStore()
        }
        
        // get the permission from the user to access the eventStore for Reminder enetity
        appDelegate!.eventStore!.requestAccessToEntityType(EKEntityType.Reminder) { (granted: Bool, error: NSError?) -> Void in
            if granted{
                // get the calander of EKreminder
                let calenders = self.appDelegate!.eventStore!.calendarsForEntityType(EKEntityType.Reminder)
                // search reminder in the calender
                let predicate = self.appDelegate!.eventStore!.predicateForRemindersInCalendars(calenders)
                // if found  reminder set the datasource for reminders table view
                self.appDelegate!.eventStore!.fetchRemindersMatchingPredicate(predicate, completion: { (reminders: [EKReminder]?) -> Void in
                    
                    if let savedreminders = reminders {
                        self.reminders = savedreminders
                    }
                    dispatch_async(dispatch_get_main_queue()) {
                        self.tableView.reloadData()
                    }
                })
            }else{
                print("Error! You do not have permission")
            }
        }
    }
    // Unwind segue to get control back to Reminder Table View from Reminder detail screen
    @IBAction func unwindToTaskList(sender: UIStoryboardSegue) {
        if let _ = sender.sourceViewController as? TaskDetailVC {
            
        }
        
    }
}


